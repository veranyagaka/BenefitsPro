const express = require('express')
const app =express()
const mongoose =require('mongoose')
const url ="mongodb+srv://nyagakavera:1234@myfirstdatabase.burnsb7.mongodb.net/?retryWrites=true&w=majority"
async function connect(){
    try{
        await mongoose.connect(url)
        console.log("Connected to MongoDB")
    }catch(error){
        console.error(error)
    }
}
connect()
const PORT =3000
app.listen(PORT, ()=>console.log(`Server is running on port ${PORT}`))